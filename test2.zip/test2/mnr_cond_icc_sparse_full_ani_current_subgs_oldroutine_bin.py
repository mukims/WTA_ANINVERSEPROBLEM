#!/usr/bin/env python
##import matplotlib as mpla
##mpla.use('Agg')
from shapely.geometry import LineString, MultiLineString, MultiPoint, Point
#from shapely.ops import cascaded_union
#from scipy.misc import comb
import scipy.stats as stats
#from scipy.misc import imread
import matplotlib.pyplot as plt
##import matplotlib.colors as mpl
##from matplotlib import cm
##import matplotlib.gridspec as gridspec
#import matplotlib.patches as patches
import networkx as nx
import math
import random
import json
import os
import numpy as np
from collections import Counter, defaultdict
from itertools import islice, product, combinations
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import spsolve

from cvxopt import matrix, solvers
from cvxopt.base import sparse
from cvxopt.base import matrix as m
from cvxopt.lapack import *
from cvxopt.blas import *
import cvxopt.misc as misc
#from symmlq import *
from minres import *

import pandas as pd



def Gfun(x,y,trans='N'):
    ''' Function that passes matrix A to the symmlq routine which solves Ax=B.'''
    gemv(Amatrix,x,y,trans)

def distance_scale(x1,y1,x2,y2):
    return math.sqrt( (x1 - x2)**2 + (y1 - y2)**2  )

# Parameters for solving the linear system of equations
tol=1e-15
show=False
maxit=None

##imname = 'A2T_Middle_clip.jpg'
##img = imread(imname)

# Open files containing the coordinates
coordsname = 'C3_top_2_3_clip_coords_manual.txt'    # Name of the file with the coordinates
coords_read = open(coordsname,'r')
coords = coords_read.readlines() 
coords_read.close()

# Set True if one wants to label wires in the plots
label_wires = False

# File which contains the scale bar coordinates
scale = 'C3T Middle_other_scale_coords.txt' 
scale_read = open(scale,'r')
scale_bar = scale_read.readlines() 
scale_read.close()

# Obtaining scale bar coordinates
point_bar1 = scale_bar[0].split()
x1_scale = float(point_bar1[0])
y1_scale = float(point_bar1[1])

point_bar2 = scale_bar[1].split()
x2_scale = float(point_bar2[0])
y2_scale = float(point_bar2[1])

# Length of the scale bar
scale_length = distance_scale(x1_scale, y1_scale, x2_scale, y2_scale)

# Factor to convert length to Nm
scale_length_fig = 10000 # Nm

# Read odd and even lines of the file
odd_lines = [coords[i] for i in range(len(coords)) if i%2 == 1]
even_lines = [coords[i] for i in range(len(coords)) if i%2 == 0]

# Get total number of wires (including leads)
nwires_plus_leads = int(len(coords)/2)
print('The total number of wires (plus leads) is ', nwires_plus_leads)

# Get initial positions
x1 = np.empty(len(even_lines))
y1 = np.empty(len(even_lines))

for i, ilines in enumerate(even_lines):
     point1 = ilines.split()
     x1[i] = float(point1[0])
     y1[i] = float(point1[1])

# Get final positions
x2 = np.empty(len(odd_lines))
y2 = np.empty(len(odd_lines))

for i, ilines in enumerate(odd_lines):
     point2 = ilines.split()
     x2[i] = float(point2[0])
     y2[i] = float(point2[1])

# Zip (x1,y1)-(x2,y2) in accordance to shapely format 
coords1 = list(zip(x1,y1))
coords2 = list(zip(x2,y2))

midpoint_coordsx = (x1 + x2) / 2.0
midpoint_coordsy = (y1 + y2) / 2.0

coords = list(zip(coords1,coords2))
mlines = MultiLineString(coords)

# Block to determine dimensions of the network substrate
l0 = (mlines[0].length)*(scale_length_fig / scale_length)
print('Length of electrode 0: ', l0, ' Nm')
l1 = (mlines[1].length)*(scale_length_fig / scale_length)
print('Length of electrode 1: ', l1, ' Nm')
d0 = mlines[0].distance(mlines[1])*(scale_length_fig / scale_length)
d1 = mlines[1].distance(mlines[0])*(scale_length_fig / scale_length)
print('Their separation is: ', d0, d1, ' Nm')
lmax = max([l0,l1])
print('The area is: ', lmax*d0, lmax*d1, ' Nm^2\n')

# proportionality constant for single junction G = alph*icc
alph = 0.05
expon = 0.9

# Resistances of junctions in off state
Roff = 10000.0

# Resistances of junctions in on state
Ron = 12.0   

# Characteristic resistivity (silver)
rho0 = 22.63676 # Nano Ohm m

# Characteristic diameter
D0 = 60.0 # Nm

# Cross section areas
A0 = math.pi * (D0 / 2.0)**2

# Parameters for current scan
i0 = 0.01
iif = 10.0
istep = 0.01
num_i = np.arange(i0,iif,istep)

# all pair wire combination
lines_comb = combinations(mlines, 2)

# list storing True or False for pair intersection
intersection_check = [pair[0].intersects(pair[1]) for pair in lines_comb]

# list storing the indexes of intersection_check where the intersection between two wires is TRUE
intersections = [i for i, x in enumerate(intersection_check) if x]

# full list containing all non-repeated combinations of wires
combination_index = list((i,j) for ((i,_),(j,_)) in combinations(enumerate(mlines), 2))

# list storing the connection (wire_i, wire_j) 
intersection_index = [combination_index[intersections[i]] for i in range(len(intersections))]

# checking the coordinates for interesection points
inter_point_coll = [pair[0].intersection(pair[1]) for pair in combinations(mlines, 2)]

# eliminating empty shapely points from the previous list
no_empty_inter_point_coll = [inter_point_coll[intersections[i]] for i in range(len(intersections))]

# total number of intersections
nintersections = len(intersection_index)

print('The total number of intersections is: ', nintersections, '\n')

# dictionary containing wire index: [list of wires connected to it]
wire_touch_list = defaultdict(list)
for k, v in intersection_index:
    wire_touch_list[k].append(v)
    wire_touch_list[v].append(k)

# dictionary containing wire index: [label nodes following MNR mapping]
wire_touch_label_list = defaultdict(list)
each_wire_inter_point_storage = defaultdict(list)
new_pos_vec = defaultdict(list)
label = 2

# Starting creating the new node labelling according to MNR mapping
for i in wire_touch_list.items(): #iter(wire_touch_list.viewitems()):
    for j in range(len(i[1])):
        cpoint = mlines[i[0]].intersection(mlines[i[1][j]])
        npoint = (cpoint.x,cpoint.y)
        each_wire_inter_point_storage[i[0]].append(npoint)
        
        if i[0] > 1:
            wire_touch_label_list[i[0]].append(label)
            new_pos_vec[label].append(npoint)
            label += 1
        else:
            wire_touch_label_list[i[0]].append(i[0])
            if i[0] == 0:
                new_pos_vec[0].append(npoint)
            if i[0] == 1:
                new_pos_vec[1].append(npoint)


maxl = label # dimension of the resistance matrix

print('Dimension of the resistance matrix: ', maxl,' x ', maxl, '\n')

# flattening intersection_index for counting the amount of occurances of wire i
flat = list(sum(intersection_index, ())) 
conn_per_wire = Counter(flat)

# checking for isolated wires
complete_list = range(nwires_plus_leads)
isolated_wires = [x for x in complete_list if not x in flat]

print('Isolated wires: ', isolated_wires, '\n')

# list containing the length segments of each wire (if it has a junction)
each_wire_length_storage = [[] for _ in range(nwires_plus_leads)]  

# Routine that obtains the segment lengths on each wire
for i in each_wire_inter_point_storage:
    
    point_ini = Point(mlines[i].coords[0])  # Initial point of the wire
    point_fin = Point(mlines[i].coords[1])  # Final point of the wire
    wlength = point_ini.distance(point_fin) # Whole length
    wire_points = each_wire_inter_point_storage[i]

    dist = [0.0]*(len(wire_points)+1)
    for j in range(len(wire_points)):
        point = Point(wire_points[j])
        dist[j] = point_ini.distance(point)

    dist[-1] = wlength  # Whole length stored on the last component of dist vector.
    dist.sort() # Sorting in crescent order

    dist_sep = [0.0]*len(dist)
    dist_sep[0] = dist[0]
    dist_sep[1:len(dist)] = [dist[k]-dist[k-1] for k in range(1,len(dist))] # Segment lengths calculated for a particular wire
    each_wire_length_storage[i].append(dist_sep)

# starting building resistance matrix
mr_matrix = np.zeros((maxl, maxl))

# matrix storing the labels of ONLY junctions
mr_matrix_info = np.zeros((maxl,maxl))

# Matrix storing coordinates of intersection points
interpos_matrix = np.zeros((maxl,maxl),dtype=object)
innerpos_matrix = np.zeros(maxl,dtype=object)
pos_vec = np.zeros(maxl,dtype=object)

# list to store all junction resistances
resis_list = []

# file containing information of mr_matrix
matrix_mr = open('matrix_mr.dat', 'w')

# start graph that will store only inner edge connections
mnr_nodes = range(maxl)
G = nx.Graph()
G.add_nodes_from(mnr_nodes)

# Procedure to build the resistance matrix (mr_matrix) which assumes that the wires are not in the same potential.
# The procedure is:
# For each iwire wire...
for iwire in range(nwires_plus_leads):
    # if each_wire_inter_point_storage[iwire] is not empty, the procedure can start.
    if each_wire_inter_point_storage[iwire]:
        # First we obtain the capacitance matrix elements related to the internal "capacitances"...
        # This procedure is similar to the one used above for building multilinestring segments.
        # Scan all the junction coordinate points stored in each_wire_inter_point_storage[iwire].
        for j, pointj in enumerate(each_wire_inter_point_storage[iwire]):
            # Reserve a particular point of this list.
            point = Point(pointj)
            # Scan all the junction coordinate points stored in each_wire_inter_point_storage[iwire].
            for i, pointw in enumerate(each_wire_inter_point_storage[iwire]):
                # Reserve another point of this list.
                comp_pointw = Point(pointw)
                # Calculate the distance between point - comp_pointw
                inter_dist = point.distance(comp_pointw)
                # A 4 digit precision for this distance must be imposed otherwise, a comparison between exact numbers can fail.
                round_inter_dist = round(inter_dist, 4)
                # Check if each_wire_length_storage[iwire] contains a segment length that matches round_inter_dist.
                # If it does, we found a capacitance matrix element correspondent to an inner "capacitance".
                for il in each_wire_length_storage[iwire][0]:
                    value = float(il)
                    value = round(value,4)
                    if value == round_inter_dist and value != 0:
                        if iwire != 0 and iwire != 1 and mr_matrix[wire_touch_label_list[iwire][i], wire_touch_label_list[iwire][j]] == 0.0:
                            inner_resis = (float(value) * rho0 / A0) * (scale_length_fig / scale_length)
                            #inner_resis = inner_resis/1000.0
                            # ELEMENT FOR mr_matrix FOUND! Its labels are stored in wire_touch_label_list.
                            mr_matrix[wire_touch_label_list[iwire][i], wire_touch_label_list[iwire][j]] = -1.0/inner_resis
                            mr_matrix[wire_touch_label_list[iwire][j], wire_touch_label_list[iwire][i]] = -1.0/inner_resis
                            
                            innerpos_matrix[wire_touch_label_list[iwire][i]] = comp_pointw
                            innerpos_matrix[wire_touch_label_list[iwire][j]] = point
                            G.add_edge(wire_touch_label_list[iwire][i],wire_touch_label_list[iwire][j])

                            #posi = (comp_pointw.x, comp_pointw.y)
                            #G.add_node(wire_touch_label_list[iwire][i], pos=posi)
                            
                            #posj = (point.x, point.y)
                            #G.add_node(wire_touch_label_list[iwire][j], pos=posj)
                            #G.add_edge(wire_touch_label_list[iwire][i],wire_touch_label_list[iwire][j],weight=1)

                            matrix_mr.write('%s %s %s %s\n' % (wire_touch_label_list[iwire][i], wire_touch_label_list[iwire][j], inner_resis, -1.0/inner_resis))
                            matrix_mr.write('%s %s %s %s\n' % (wire_touch_label_list[iwire][j], wire_touch_label_list[iwire][i], inner_resis, -1.0/inner_resis))

                            #G.add_edge(wire_touch_label_list[iwire][i],wire_touch_label_list[iwire][j])

            # Procedure to find capacitance matrix elements for the junctions...
            # Scan the list (wire_touch_list) which stores the label of wires to which iwire is connected.
            for k, label in enumerate(wire_touch_list[iwire]):
                # For a particular wire (labelled as label) in wire_touch_list, scan its junction coordinate points stored in (each_wire_inter_point_storage[label].
                for kk, pointk in enumerate(each_wire_inter_point_storage[label]):
                    # Reserve one of the junction points.
                    pointk = Point(pointk)
                    # Calculate the distance between point - pointk
                    inter_dist = point.distance(pointk)
                    # A 4 digit precision for this distance must be imposed otherwise, a comparison between exact numbers can fail.
                    round_inter_dist = round(inter_dist, 4)
                    # If round_inter_dist is ZERO, it means we FOUND a junction capacitance element that is stored in mr_matrix.
                    # Its value is computed from the Gaussian distribution.
                    if round_inter_dist == 0 and mr_matrix[wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk]]== 0:
                        #if sigma_r != 0:
                            #resis = resis_dist.rvs()
                        #else:
                            #resis = resis0

                        resis = Roff

                        mr_matrix[wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk]] = -1.0/resis
                        mr_matrix[wire_touch_label_list[label][kk], wire_touch_label_list[iwire][j]] = -1.0/resis

                        mr_matrix_info[wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk]] = 1.0
                        mr_matrix_info[wire_touch_label_list[label][kk], wire_touch_label_list[iwire][j]] = 1.0

                        #G.add_edge(wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk])

                        #interpos_matrix[wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk]] = pointk

                        if label == 0:
                                #print 'there is an electrode 0 in label!'
                                #print label, iwire 
                                #print point
                                interpos_matrix[wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk]] = point
                        elif label == 1:
                                #print 'there is an electrode 1 in label!'
                                #print label, iwire 
                                #print point
                                interpos_matrix[wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk]] = point
                        else:
                                #print 'there is NO electrode in label!'
                                #print label, iwire 
                                #print pointk
                                interpos_matrix[wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk]] = pointk

                        if iwire == 0:
                                #print 'there is an electrode 0 in iwire!'
                                #print label, iwire                                
                                interpos_matrix[wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk]] = pointk
                        elif iwire == 1:
                                #print 'there is an electrode 1 in iwire!'
                                #print label, iwire                                
                                interpos_matrix[wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk]] = pointk
                        else:
                                #print 'there is NO electrode in iwire!'
                                #print label, iwire 
                                #print point
                                interpos_matrix[wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk]] = point



                        pos_vec[wire_touch_label_list[label][kk]] = pointk
                        pos_vec[wire_touch_label_list[iwire][j]] = pointk

                        resis_list.append(resis)
                        matrix_mr.write('%s %s %s %s\n' % (wire_touch_label_list[iwire][j], wire_touch_label_list[label][kk], resis, -1.0/resis))
                        matrix_mr.write('%s %s %s %s\n' % (wire_touch_label_list[label][kk], wire_touch_label_list[iwire][j], resis, -1.0/resis))

# array storing the index of the non-zero elements of mr_matrix_info (only on its upper diagonal part)
neigh_mr = np.nonzero(np.triu(mr_matrix_info))
inner_edges = G.edges()

# Sum the non-zero elements on each row of mr_matrix
sum_rows_mr = mr_matrix.sum(1)

# Place them in the diagonal and change their signal with abs()
np.fill_diagonal(mr_matrix, abs(sum_rows_mr))

# Initial resistance histogram for the junctions
dframe = 0
files_dist = []
dpi = 200
npot = 20

#hist_resis0 = open("hist_resis0.dat","w")
#resis_hist = np.asarray(resis_list)
#occ, hist = np.histogram(resis_hist, bins=100, normed=False)
#print >> hist_resis0, "\n".join(("%s  %s" % t for t in zip(hist,occ)))
#hist_resis0.close()

#figr = plt.figure(facecolor='w')
#n3, bins3, patches3 = plt.hist(resis_hist, bins=100, facecolor='red', alpha=0.75)
#plt.xlim([Ron-5, Roff+1000])
#plt.xlabel('Resistance')
#plt.ylabel('Occurrence')
#plt.grid(True)

#fdist = 'dist_%04d.png'%dframe
#plt.savefig(fdist, bbox_inches='tight', dpi=dpi)
#files_dist.append(fdist)
#plt.close(figr)
#figr.clf()

dframe += 1

#mr_matrix = mr_matrix.tocsr()
#mr_sparse = csr_matrix(mr_matrix)


for i in range(maxl):
    matrix_mr.write('%s %s %s %s\n' % (i, i, mr_matrix[i,i], mr_matrix[i,i]))

matrix_mr.close()

#del mr_matrix
#del mr_matrix_info

# Storing information about the resistance matrix and new labeling scheme
json.dump(wire_touch_list, open('wire_touch_list.dat','w')) 
json.dump(wire_touch_label_list, open('wire_touch_label_list.dat','w')) 
json.dump(each_wire_inter_point_storage, open('each_wire_inter_point_storage.dat','w')) 
json.dump(new_pos_vec, open('new_pos_vec.dat','w')) 



# file storing resistance versus ic
resist_info = open('conductance_icc.dat','w')

# file storing power versus ic
power_info = open('power_icc.dat','w')

frame = 0
files = []
#dpi = 200
fps = 1

list_ic = []
list_conductance = []
list_power = []

# Starting current loop
for ic in num_i:

    # Open figure elements: panels appear in subplots
    ##fig = plt.figure(facecolor='w')
    ##gs = gridspec.GridSpec(1, 2,
    ##                       width_ratios=[1,1.1],
    ##                   height_ratios=[1.1,1]    
    ##                   )

    ##ax1 = plt.subplot(gs[0])
    #fig.subplots_adjust(wspace=10.0)
    #ax1 = fig.add_subplot(111, axisbg='white')
    #ax1 = plt.subplot2grid((1,2),(0,0))
    ##ax1.set_title('Varying current of ic = %.3f' % ic, fontsize = 8)
    ##ax1.axis('off')
    #ax1.set_aspect('equal', adjustable='box')
    
    #for line in mlines:
    #    xl, yl = line.xy
    #    ax1.plot(xl, yl, color='r', lw=2, zorder=1)
    
    #x0, y0 = mlines[0].xy
    #ax1.plot(x0, y0, color='b', lw=4, zorder=2)
    
    #x1, y1 = mlines[1].xy
    #ax1.plot(x1, y1, color='b', lw=4, zorder=2)
       
    #for point in inter_point_coll:
    #    xl, yl = point.xy
    #    ax1.plot(xl, yl, color='black', marker='o', markersize=4, zorder=3)    
        
    #xp = []
    #yp = []
    #cp = []
    #for i in range(len(neigh_mr[0])):
        #apoint = mlines[neigh_mr[0][i]].intersection(mlines[neigh_mr[1][i]])
        #apoint = interpos_matrix[int(neigh_mr[0][i]),int(neigh_mr[1][i])]
        #axp, ayp = apoint.xy
        #xp.append(axp)
        #yp.append(ayp)
        #resis_color = (abs(1.0/mr_matrix[int(neigh_mr[0][i]),int(neigh_mr[1][i])]))#/Roff
        #cp.append(resis_color)

        #colors = ['blue', 'violet', 'white', 'pink', 'red', 'darkred']
        #levels = np.linspace(0,1,len(colors))#[0, 0.25, 0.5, 0.75, 1]

        #cmap, norm = mpl.from_levels_and_colors(levels=levels, colors=colors, extend='max')
        #ax1.scatter(axp,ayp,c=resis_color, s=100, marker='*', cmap=cmap, norm=norm,zorder=9)

    #cm = plt.cm.get_cmap('RdYlBu')
    ##ax1.scatter(xp,yp,c=cp, vmin=Ron, vmax=Roff, s=30, marker='*', lw=0.5, cmap=cm.coolwarm, zorder=9)

  
    #if label_wires:
    #    label = np.arange(0,nwires_plus_leads,1)
    #    for i in range(0,nwires_plus_leads):
    #        ax1.text(midpoint_coordsx[i], midpoint_coordsy[i], str(label[i]), fontsize=12)
    
    ##plt.gca().invert_yaxis()
    ##plt.imshow(img, zorder=0)
    #plt.grid(True)
    
    # Initiating fixed current vector
    iv = np.zeros(maxl)
    iv[0] = +ic
    iv[1] = -ic
    Imatrix = m(iv)

    #iv_sparse = csr_matrix(iv)
    #pot = spsolve(mr_sparse,iv_sparse)
    mr_matrix_form = m(mr_matrix)
    Amatrix = mr_matrix_form
    elec_pot_mr = minres( Gfun, Imatrix, show=show, rtol=tol, itnlim=maxit)
    
    # Write solution in solution_mc.dat file
    #solution_mr = open("sol_mr.dat","w")
    #solution_mr.write('  '.join([str(i) for i in elec_pot_mr[0]]))
    #solution_mr.close()

    resistance = (elec_pot_mr[0][0] - elec_pot_mr[0][1])/ic
    conductance = 1.0/resistance
    #resistance = (pot[0]-pot[1])/ic

    print('Sheet Resistance: ', resistance, ic)
    resist_info.write('%s   %s\n' % (ic, conductance))

    #ax2 = plt.subplot2grid((1,2),(0,1),colspan=3)
    list_ic.append(ic)
    list_conductance.append(conductance)
    #lc = math.log10(conductance)
    #lic = math.log10(ic)
    ##ax2 = plt.subplot(gs[1])
    ##ax2.set_yscale('log')
    ##ax2.set_xscale('log')
    ##ax2.set_xlim(0.0009,iif+0.1)
    ##ax2.set_ylim(0.0001,1.0)
    ##ax2.plot(list_ic, list_conductance)#, color='green', marker='o', markersize=4)
    ##plt.xlabel('Current (arb. units)')
    ##plt.ylabel('Conductance (arb. units)')
    ##plt.grid(True)
    #plt.subplots_adjust(wspace=0.35)


    #ax3 = plt.subplot2grid((2,2),(1,0))
    power = resistance*ic**2
    list_power.append(power)

    #print 'Power: ', power, ic
    power_info.write('%s   %s\n' % (ic, power))

    # current map (current information is saved point-by-point in an .txt that will be processed in gnuplot)
    curr_file = open("current_%04d.dat"%frame,"w")
    for ie in inner_edges:
        #print ie, innerpos_matrix[ie[0]], innerpos_matrix[ie[1]]
        pinix = innerpos_matrix[ie[0]].x
        piniy = innerpos_matrix[ie[0]].y
        
        pfinx = innerpos_matrix[ie[1]].x
        pfiny = innerpos_matrix[ie[1]].y
        aslope = (pfiny - piniy)/(pfinx - pinix)
        binter = 0.5 * (pfiny+piniy - aslope*(pfinx + pinix) )
        ix = np.linspace(pinix, pfinx, num=npot,endpoint=True)
        iy = ix * aslope + binter
        
        diff = abs(elec_pot_mr[0][ie[1]] - elec_pot_mr[0][ie[0]]) 
        curr = diff*(abs(mr_matrix[ie[1],ie[0]]))

        for ii in range(npot):
            # the minus sign in iy may be necessary depending on how the schematic figure is mirrored from the experimental image
            curr_file.write('%s  %s  %s\n' % (ix[ii], -iy[ii],curr))


    curr_file.close()

    ##fname = 'nwns_activation_frame_%04d.png'%frame
    ##plt.savefig(fname, bbox_inches='tight', dpi=dpi)
    ##files.append(fname)
    
    ##plt.close(fig)
    ##fig.clf()
    
    frame += 1


    new_resis_list = []
    # Loop over all inter-wire connections 
    for i in range(len(neigh_mr[0])):

        # ddp along the junction
        #diffmr = abs(pot[neigh_mr[0][i]]-pot[neigh_mr[1][i]])
        diffmr = abs(elec_pot_mr[0][int(neigh_mr[0][i])] - elec_pot_mr[0][int(neigh_mr[1][i])])

        # current passing through the junction
        jcurr = diffmr/(abs(1.0/mr_matrix[int(neigh_mr[0][i]),int(neigh_mr[1][i])]))

        # resistance updated as a function of its current
        new_resis=1.0/(alph*jcurr**expon)
        

        # thresholds (the junction resistance cannot be bigger than Roff or smaller than Ron)
        if new_resis > Roff:
            new_resis = Roff
        if new_resis < Ron:
            new_resis = Ron

        new_resis_list.append(new_resis)

        #print 'old resistance, current, new resistance: '
        #print abs(1.0/mr_matrix[neigh_mr[0][i],neigh_mr[1][i]]), jcurr, new_resis
        
        # modify resistance of the junction
        mr_matrix[neigh_mr[0][i],neigh_mr[1][i]] = -1.0/new_resis
        mr_matrix[neigh_mr[1][i],neigh_mr[0][i]] = -1.0/new_resis

    # Reset diagonal elements before updating Mr!
    np.fill_diagonal(mr_matrix, 0.0)
    #for idia in range(maxl):
    #    mr_sparse[idia,idia] = 0.0


    # Adds the non-zero elements on each row of Mr.
    #sum_rows_mr = mr_sparse.sum(1)
    sum_rows_mr = mr_matrix.sum(1)
    
    # Place the sum in the diagonal of Mr.
    np.fill_diagonal(mr_matrix, abs(sum_rows_mr))  

    #for idia in range(maxl):
    #    mr_sparse[idia,idia] = abs(float(sum_rows_mr[idia]))


    #mr_sparse = csr_matrix(mr_matrix)

    ###### uncomment to get the dynamics of resistances in a histogram #######
    new_resis_hist = np.asarray(new_resis_list)

    
    figr = plt.figure(facecolor='w')
    n3, bins3, patches3 = plt.hist(new_resis_hist, bins=100, facecolor='red', alpha=0.75)
    plt.ylim([0, nintersections*0.4])
    plt.xlim([Ron-5, Roff+1000])
    plt.legend([ic])
    plt.xlabel('Resistance')
    plt.ylabel('Occurrence')
    plt.grid(True)

    fdist = 'dist_%04d.png'%dframe
    fdist212 =pd.DataFrame(new_resis_hist)
    np.savetxt('dist_resis_'+str(dframe)+'.csv',new_resis_hist,fmt='%.18g')
    plt.savefig(fdist, bbox_inches='tight', dpi=dpi)
    #np.savetxt(fdist212, fmt='%.18g')
    files_dist.append(fdist)
    plt.close(figr)
    figr.clf()
    ###### uncomment to get the dynamics of resistances in a histogram #######

    dframe += 1

resist_info.close()
power_info.close()

plt.figure()
plt.loglog(num_i,list_conductance)
plt.plot(num_i,list_conductance)
plt.xlabel('current')
plt.ylabel('conductance')
plt.show()

print('Rendering an animation - this might take a while...')
os.system("mencoder 'mf://nwns_activation_frame*.png' -mf type=png:fps=%s -ovc lavc -speed 4 -lavcopts vcodec=wmv2 -oac copy -o animation.mp4"%fps)

os.system("mencoder 'mf://dist*.png' -mf type=png:fps=%s -ovc lavc -speed 4 -lavcopts vcodec=wmv2 -oac copy -o dist_animation.mp4"%fps)

